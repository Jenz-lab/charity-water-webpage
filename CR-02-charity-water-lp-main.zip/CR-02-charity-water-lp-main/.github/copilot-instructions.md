Students are beginners learning the basics of HTML and CSS.

We provide the simplest, beginner-friendly code possible.

We do not use advanced CSS layout methods like grid.

We provide comments to help students understand each part of the generated code.
